package com.walhalla.data.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.walhalla.data.model.Channel;

import java.util.List;

@Dao
public interface ChannelDao {

    @Insert
    void addData(List<Channel> channels);

    @Query("select * from channels")
    void getAllChannels(List<Channel> channels);

}
