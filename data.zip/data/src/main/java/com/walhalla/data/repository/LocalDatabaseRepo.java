package com.walhalla.data.repository;

import android.content.Context;

import androidx.room.Room;

import com.walhalla.data.database.FavoriteDatabase;
import com.walhalla.data.model.Channel;

import java.util.List;

public class LocalDatabaseRepo {

    private static LocalDatabaseRepo instance;

    private static final Object LOCK = new Object();


    private final FavoriteDatabase db;

    public LocalDatabaseRepo(Context context) {
        db = Room.databaseBuilder(context.getApplicationContext(), FavoriteDatabase.class, "favdb")
                .allowMainThreadQueries()
                .build();
    }

    public synchronized static LocalDatabaseRepo getStoreInfoDatabase(Context context) {
        if (instance == null) {
            synchronized (LOCK) {
                if (instance == null) {

                    instance = new LocalDatabaseRepo(context);
                }
            }
        }
        return instance;
    }

    public List<Channel> getFavorite() {
        return db.favoriteDao().getFavoriteData();
    }

    public int isFavorite(String tvgId) {
        return db.favoriteDao().isFavorite(tvgId);
    }

    public void addFavorite(Channel channel) {
        db.favoriteDao().addData(channel);
    }

    public void deleteFavorite(String tvgId) {
        db.favoriteDao().delete(tvgId);
    }

    public void addChannel(List<Channel> result) {
        try {
            db.channelDao().addData(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getAllChannels() {
        try {
            db.channelDao().addData(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}